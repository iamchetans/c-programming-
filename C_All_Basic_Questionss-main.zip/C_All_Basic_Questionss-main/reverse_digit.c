// reverse the digit of positive integer value


#include<stdio.h>

void main()
{
    int num, lst;
    printf("Enter the positive integer value:");
    scanf("%d", num);

    lst = num%10;
    num = num/10;

    

}