// Bitwise complement operator

#include <stdio.h>
int main()
{
    int a=14, b;
    b = ~a;
    printf("Value of c = %d\n",b);
    return 0;

}
