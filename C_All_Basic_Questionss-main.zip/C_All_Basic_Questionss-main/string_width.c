#include<stdio.h>

void main()
{
char name[20] = "Mahesh Bhatt";
printf("%s\n", name);
printf("%6s\n", name);
printf("%12.6s\n", name);
printf("%-12.6s\n", name);
printf("%.2s\n", name);
}


