// program to count the digits of given integer value

#include<stdio.h>

void main()
{
    int num;
    scanf("%d",&num);
    digit = printf("%d",num);
    printf("total digits are :- %d",digit);
    }

   
    

      

    
     
     
    
 









          

         



