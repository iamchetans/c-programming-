#include<stdio.h>
#include<stdlib.h>
extern int  x;
void main()
{   int a;
    a = 10; 
    // do{
    //     printf("loop in do segment");
    //     a--;
    // }
    // while (a);

    // for(int x=0;x<=10;++x)
    // {
    //     printf("this is my name ");
    //     // scanf("%d", &a);
    //     a--;
    //     abort();

    // }
    // printf("%d", a);

    // short ch=0;
    // while(++ch)
    // {
    //     printf("%d\t", ch);
       
    // }
  
//   printf("%d", sizeof(2.09));
    // do
    // printf("Inside the loop");
    // printf("next line in loop");
    // while (0);
    // printf("\nAfter loop");
    
    // short i;
    // for(i=1;i>=0;i++)
    //     printf("%d\n", i);
    do{
        do{
            printf("%o", x);
        }while (!-2);
        
    }while (0);

        
}
int x = 8;