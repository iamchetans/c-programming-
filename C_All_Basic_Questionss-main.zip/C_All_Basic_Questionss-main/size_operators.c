#include<stdio.h>

void main()
{
    double da = 4.5;
    double db = 4.6;
    double dc = 4.9;
    //explicitly defined by user
    int result = (int)da + (int)db + (int)dc;
    printf("result = %d", result);

}