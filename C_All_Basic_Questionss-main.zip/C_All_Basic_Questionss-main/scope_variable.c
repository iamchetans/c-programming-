#include<stdio.h>

void main()
{
    int y=10;
    // int y=3;  error re definition of y

    printf("%d\n", y);

}