#include<stdio.h>

void main()
{
    int x;
    scanf("%d", &x);
    int arr[x][x];




}