#include<stdio.h>

void main()
{
    int i=2;
    if(i>1)
    {
        printf("hello world!\n");
        if(i==2)
            break;
        printf("C-Programming");    
    }
}