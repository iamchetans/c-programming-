#include<stdio.h>

void main()
{



    int *ptr = &x, x;






    




    // int num = 10, *ptr = &num, *p1, *p2;
    // int arr[5] = {1, 4, 5, 2, 7};

    // p1 = &arr[1];
    // p2 = &arr[4];
    // --p1;
    // printf("%d", p1-p2);

    // // int* point;  // style1
    // // int *point; // style 2
    // // int * point;

   

    // printf("Value at address %p is %d", ptr, *ptr);

}