#include<stdio.h>
void main()
{ int a,b;
printf("Enter two Numbers : ");
scanf("%d %d",&a,&b);
c=a*b;
printf("The Multiplication is %d",c);
}
