#include<stdio.h>

void main()
{
    int a;
    a = -3 -- 3;
    printf("%d", a);
    // float f;
    // double d;
    // scanf("%1f", &f);
  
    // printf("%f", f);



    // printf("\n\n%d", sizeof(long double));
    // printf("\n\n%d", sizeof(float));


}
