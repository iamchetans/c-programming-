#include<stdio.h>

// void main()
// {
//     int a=2,p;
//     p= 1==2!=3;
//     printf("value of p %d\n",p);
//     printf("Value of a %d", a);
// }



int main() 
{
   
    // printf("%c", c);
    int a;
    for(a=0;;)
    printf("hello");

}
