// even odd program
#include<stdio.h>

void main()
{
    // int a, b=1;
    // printf("Enter the number ");
    // scanf("%d", &a);
    // printf("%d\n", b=10);
    // if(a%2)
    //     printf("Odd");
    // else
    //     printf("Even");
    int a;
    a=0;
    while(a=10)
    printf("in loop\n");
    printf("after loop");
        
}