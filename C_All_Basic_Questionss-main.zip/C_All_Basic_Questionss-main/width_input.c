// input stream width with  scanf()

#include<stdio.h>

void main()
{
    printf("This is first line\n");
    printf("Kaustubh Dubey");
   // printf("\b\b\b\bVishal");
    printf("\rVinay");
    
}

