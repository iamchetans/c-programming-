#include<stdio.h>

void main()
{   
        char arr[1000]={'M', 'A', 'A', 'M', '\0'};
        char name[100]="Amir";

        
        printf("%s", arr);

        
}