// Bitwise and operator

#include <stdio.h>
int main()
{
    int a=14, b= 7, c;
    c =a&b;
    printf("Value of c = %d\n",c);
    return 0;

}
