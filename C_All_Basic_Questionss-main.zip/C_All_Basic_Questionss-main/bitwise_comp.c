#include<stdio.h>

void main()
{
// char a, x;
// a = 5&50;
// printf("%%%d"+2, a);
int num;
printf("%b", num);

}


    // x = ++a + ++a;

    // printf("%d", x);
