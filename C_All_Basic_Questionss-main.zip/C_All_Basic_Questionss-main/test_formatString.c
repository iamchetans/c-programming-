#include<stdio.h>

void main()
{
    int n;
    n=2;
    char ch[5]="%%%dd";
    printf(ch, n);
}