#include<stdio.h>

int main()
{   int num;
    printf("value of bitwise and %d", 2&4);
    scanf("%d", num);


    
}