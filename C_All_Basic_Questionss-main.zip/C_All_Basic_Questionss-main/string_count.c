// count the number of words in a given string 
// count the number of special char, Alphabet upper and lower and digits

#include<stdio.h>
#include<string.h>
void main()
{
char str[100];
int i=0, count_upr=0, count_lwr=0, count_digits=0, count_spcl=0;
printf("enter the string ");
gets(str);

for(i=0; str[i] != '\0'; i++)    
   {
        if(str[i] >= 65 && str[i]<= 90)
            count_upr++
        else if()    
        
   }

}