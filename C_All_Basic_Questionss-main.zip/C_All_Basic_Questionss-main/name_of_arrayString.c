#include<stdio.h>
#include<string.h>

void main()
{
    char names[10][20]={"Amir", "Asif"};
    int N; 
    // printf("Enter the number of name: ");
    // scanf("%d\n", &N);
    // scanf("\n");
    // gets(names[0]);
    // for(int i=0; i<N; i++)
    // {
    //     printf("Enter the name ");
    //     // scanf("%s", names[i]);
    //     gets(names[i]);
    // }
    // printf("\nBefore Sorting\n");
    // for(int i=0; i<N; i++)
    //     printf("%s\t",i+1, names[i]);
    N = strcmp("Manual", "ManuaL");
    // printf("%d", strcpy(names[0], names[1]));
    printf("\n%d\n", N );
    // logic here 
    // for(int i=0; i<N-1; i)
    // {
    //     for(int j=0; j<N-1-i; j++)
    //     {
    //         if(strcmp(names[j], names[j+1]))
    //     }
    // }



    // printf("\nAfter sorting\n");
    // for(int i=0; i<N; i++)
    //     printf("%s\t",i+1, names[i]);


}